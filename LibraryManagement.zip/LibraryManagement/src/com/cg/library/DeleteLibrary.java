package com.cg.library;

	import java.util.List;
import java.util.Scanner;

	import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
	public class DeleteLibrary {

		public static void main(String[] args) {
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("LibraryManagement");
			EntityManager em= emf.createEntityManager();
			em.getTransaction().begin();
			System.out.println("enter id");
			Scanner sc =new Scanner(System.in);
			int id =sc.nextInt();
			Library l1= em.find(Library.class, id);
			em.remove(l1);
			em.getTransaction().commit();
			System.out.println("hey u deleted successfully");
			em.close();
			emf.close();
			
		}

	}