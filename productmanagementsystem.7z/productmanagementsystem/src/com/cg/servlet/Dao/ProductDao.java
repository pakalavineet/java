package com.cg.servlet.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

	public class ProductDao {

		Connection con=null;
		PreparedStatement ps=null;
		public Connection getConnection(){
			try{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url="jdbc:oracle:thin:@localhost:1521:XE";
				String user="system";
				String pass="Capgemini123";
				con =DriverManager.getConnection(url,user,pass);
				return con;
			}
			catch(Exception e){
				e.printStackTrace();
				return con;
			}
			
			
		}
		public boolean  validateUser(String username,String password){
			try{
			con=getConnection();
			String sql="select * from user_details where username=? and password=?";
				ps=con.prepareStatement(sql);
				ps.setString(1, username);
				ps.setString(2,password);
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					return true;
				}
				else{
					return false;
				}
			}
			catch(Exception e){
				e.printStackTrace();
				return false;
			}
			
		}
		
		public int add(String pid, String pname, String model, String price) {

			con = getConnection();

			String sql = "insert into products values(?,?,?,?)";

			try {

			ps = con.prepareStatement(sql);

			ps.setString(1, pid);

			ps.setString(2, pname);

			ps.setString(3, model);

			ps.setString(4, price);

			 
			int n = ps.executeUpdate();

			return n;

			} catch(Exception e) {

			e.printStackTrace();

			}

			 

			return 0;

			}

		public int insert_details(String username, String password, String mail, String mobileno) {
			
			 
			con = getConnection();
			 
			String sql = "insert into user_details values(?,?,?,?)";
			 
			try {
			ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, mail);
			ps.setString(4, mobileno);
			int n = ps.executeUpdate();
			return n;
			} catch(Exception e) {
			e.printStackTrace();
			return 0;

			}

			}
		public int editPrice(String pid, String price) {

			con =getConnection();
				String sql="update products set price=? where pid=?";
				 
				try
				{
				ps=con.prepareStatement(sql);
				ps.setString(1,price);
				ps.setString(2,pid);
				int n=ps.executeUpdate();
				return n;
				 
				}catch(Exception e)

				{
				e.printStackTrace();
				}
				return 0;

			
		}
		
		
	
	public int delete(String pid) {

		
		con =getConnection();

		String sql="delete products where pid=?";
		 
		try
		{

		ps=con.prepareStatement(sql);

		ps.setString(1,pid);

		int n=ps.executeUpdate();

		return n;
 

		}catch(Exception e)
		{

		e.printStackTrace();

		}
		return 0;

	}}
	


