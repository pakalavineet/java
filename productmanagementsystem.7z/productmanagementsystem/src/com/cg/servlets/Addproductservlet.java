package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.Dao.ProductDao;

/**
 * Servlet implementation class Addproductservlet
 */
@WebServlet("/Addproductservlet")
public class Addproductservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		String pid = request.getParameter("pid");

		String pname = request.getParameter("pname");

		String pmodel = request.getParameter("model");

		String price = request.getParameter("price");

		ProductDao dao = new ProductDao();

		int n = dao.add(pid, pname, pmodel, price);

		if(n > 0) { 

		response.sendRedirect("home.jsp");

		} else {

		RequestDispatcher rd = request.getRequestDispatcher("add.jsp?emsg=Something went wrong");

		rd.include(request, response);

		}

		 

		}}