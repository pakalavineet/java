package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.Dao.ProductDao;


public class registerservlet extends HttpServlet {
 
private static final long serialVersionUID = 1L;

 
/**
 
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

*/
 
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	String username =request.getParameter("user");
	String password =request.getParameter("pass");
	String mailid =request.getParameter("mailid");
	String mobileno =request.getParameter("number");
	ProductDao dao =new ProductDao();
	int n= dao.insert_details(username, password, mailid, mobileno);
	if(n>0){
		
		response.sendRedirect("login.jsp");
	}
	else{
		RequestDispatcher rd= request.getRequestDispatcher("register.jsp?emsg=something went wrong");
		rd.include(request,response);
	}
	

}
}