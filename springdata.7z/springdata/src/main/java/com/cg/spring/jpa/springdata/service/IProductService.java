package com.cg.spring.jpa.springdata.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.jpa.springdata.bean.Product;

@Service
public interface IProductService {

	public List<Product> getAllproducts();

	public void addproducts(int id, String name, double price);

	public String  updateproducts(int id, String name);

	public String deleteproducts(int id);
}
