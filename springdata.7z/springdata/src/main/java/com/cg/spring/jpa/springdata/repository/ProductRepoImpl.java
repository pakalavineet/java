package com.cg.spring.jpa.springdata.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.jpa.springdata.bean.Product;
@Component
public class ProductRepoImpl implements IProductRepo {
List<Product> list;

@Autowired
EntityManager entityManager;
	@Override
	public List<Product> getAllproducts() {
		Query q =entityManager.createQuery("from product");
		list =q.getResultList();
		return list;
	}
	@Override
	@Transactional
	public void addproducts(int id, String name, double price) {
		Product p=new Product();
		p.setId(id);
		p.setName(name);
		p.setPrice(price);
		entityManager.persist(p);
	}
	@Override
	@Transactional
	public String updateproducts(int id, String name) {
		Product p2 =entityManager.find(Product.class,id);
		p2.setName(name);
		entityManager.persist(p2);
		return "updated";
		
	}
	@Override
	@Transactional
	public String deleteproducts(int id) {
		Product p2=entityManager.find(Product.class, id);
		entityManager.remove(p2);
		return "deleted";
	}

}
