package com.cg.spring.jpa.springdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.repository.IProductRepo;

@Component
public class ProductServiceImpl  implements IProductService{

	@Autowired
	IProductRepo repo;

	@Override
	public List<Product> getAllproducts() {
		
		return repo.getAllproducts();
	}

	@Override
	public void addproducts(int id, String name, double price) {
	repo.addproducts(id,name,price);	
	}

	@Override
	public String updateproducts(int id, String name) {
		return repo.updateproducts(id, name);
		
	}

	@Override
	public String deleteproducts(int id) {
	
		return repo.deleteproducts(id);
	}

	
}
