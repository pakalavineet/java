package com.cg.spring.jpa.springdata;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.service.IProductService;

@RestController
@ComponentScan(basePackages="com.cg.spring.jpa.springdata")
public class ProductController {
@Autowired
IProductService service;

public List<Product> getAllproducts(){
	return service.getAllproducts();
}
@RequestMapping("/add/{id}/{name}/{price}")
public void addproducts(@PathVariable("id") int id,@PathVariable("name")String name,@PathVariable("price") double price) {
service.addproducts(id,name,price);
}
@RequestMapping("/update/{id}/{name}")
public String updateproducts(@PathVariable("id") int id,@PathVariable("name")String name ) {
	return service.updateproducts(id,name);
	 
	
	
}
@RequestMapping("/delete/{id}")
public String deleteproducts(@PathVariable("id")int id ) {
	return service.deleteproducts(id);
}
}