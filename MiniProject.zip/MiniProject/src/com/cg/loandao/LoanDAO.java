package com.cg.loandao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.ws.Response;

public class LoanDAO {

	Connection con=null;
	PreparedStatement ps=null;
	public Connection getConnection()
	{
		Connection con=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String pass="Capgemini123";
		con=DriverManager.getConnection(url,user,pass);
	} catch (Exception e) {
		e.printStackTrace();
	}
	return con;
	}
	public int adduserdetails( String name, String dob, String marital,String mobile, String dependencies, String email) 
	{
	con=getConnection();
		String sql="insert into customerdetails values(application_id_seq.nextval-1,?,?,?,?,?,?)";
		int n=0;
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1,name);
			String std[] = dob.split("-");
			 int y = Integer.parseInt(std[0]);
			 int m = Integer.parseInt(std[1]);
			 int d = Integer.parseInt(std[2]);
			ps.setDate(2, new java.sql.Date(y, m, d));
			ps.setString(3,marital);
			ps.setString(4,mobile);
			ps.setString(5,dependencies);
			ps.setString(6,email);
			n=ps.executeUpdate();
			 } catch (SQLException e) {
			e.printStackTrace();
		}
		return n;
		
	}
	public int loandetails( String loanprogram,String loan, String address, String income, String proof,String guarantee, String marketvalue) 
	{
		con=getConnection();
		String sql="insert into loanapplication values(application_id_seq.nextval,sysdate,?,?,?,?,?,?,?,?,sysdate+5)";
		int x=0;
		try {
			String aadhar="aadhar";
			String pan="pan";
			ps=con.prepareStatement(sql);
			ps.setString(1,loanprogram);
			ps.setString(2,loan);
			ps.setString(3,address);
			ps.setString(4,income);
			ps.setString(5, proof);
			ps.setString(6,guarantee);
			ps.setString(7,marketvalue);
			if(proof.equals(aadhar) || proof.equals(pan))
			{
				ps.setString(8,"accepted");
			}
			else
			{
			ps.setString(8,"rejected");
			}
			x=ps.executeUpdate();
			 } catch (SQLException e) {
			e.printStackTrace();
		}
		return x;
		
	}
	public String getId() throws SQLException
	{
		con=getConnection();
		
		String sql="select max(application_id) from loanapplication";
		ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			return rs.getString(1);
		}
		return sql;
			
	}
	public String getDate(String id) throws SQLException
	{
		con=getConnection();
		
		String sql="select dateofinterview from loanapplication where application_id=?";
		ps=con.prepareStatement(sql);
		ps.setString(1,id);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			return rs.getString(1);
		}
		return sql;
			
	}
	
}
