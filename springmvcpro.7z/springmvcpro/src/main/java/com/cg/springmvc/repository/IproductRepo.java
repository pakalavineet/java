package com.cg.springmvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.beans.Product;
@Repository
public interface IproductRepo {
List<Product> getAllProducts();
void add(Product P);
Product searchById(int id);
}
