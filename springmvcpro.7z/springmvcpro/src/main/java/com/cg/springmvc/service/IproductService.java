package com.cg.springmvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.springmvc.beans.Product;
@Service
public interface IproductService {
	List<Product> getAllProducts();
	void add(Product p);
	Product searchById(int id);
	
	
}
